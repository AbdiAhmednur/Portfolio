

function Contact(){
    return (
        <section id="contact">
        <h1>Contact Me</h1> 
        <p>Want to work together?</p>
        <p><strong>Email:</strong> <a href="mailto:aabdi35@hotmail.com">aabdi35@hotmail.com</a> </p>
        <p><strong>Linkedin:</strong> <a href="www.linkedin.com/in/abdi-ahmednur/">Abdi Ahmednur</a></p>
      </section>
    
    )
  
    
    }
    
    export default Contact;