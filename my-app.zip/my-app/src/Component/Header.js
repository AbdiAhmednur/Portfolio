

function Headers() {

    return (
        <div className="Logo">
            <img src="../Pictures/Web Developer.png" alt="logo" className="logo"/>
        </div>




    )



}

export default Headers;