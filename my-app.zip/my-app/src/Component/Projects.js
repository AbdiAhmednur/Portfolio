
function projects(){
  const projectList = [
    {
     name: `Meme Generator`,
     description: `A meme generator web app made using react. The memes were fetched from a meme api and the page was styled using CSS. The app generates random meme from the api, and has two inputs where the top and bottom text on the meme can be added.`,
     image: `../Pictures/meme-generator.png`,
     Source: `https://github.com/AbdiAhmednur/Meme-Generator`

    },
    
    {
      name: `Travel journal`,
      description: `A travel journal made using react. the destination are contained in a separate data file and mapped onto the app, so they can be updated and the page would accordingly, instead of having to hardcore the details.`,
      image: `../Pictures/Travel journal picture.png`,
      source: `https://github.com/AbdiAhmednur/Travel-Journal`

    },

    {
      name: `tenzies`,
      description: `A tenzies game web app. The game is essentially won when you manage to roll 10 out of the same number as soon as possible. I used React and CSS to style, made use of the useEffect and useState to enable the game to function. `,
      image: `..//Pictures/Tezenis.png`,
      source: `https://github.com/AbdiAhmednur/Tenzies-App`




    },

  ];

  const projects = projectList.map (project => (

    <div className="flex">
    <div className="project-content">
    <h2 className="project-title">{project.name}</h2>
    <p>{project.description}</p>  
    <br />
    <a className="source-btn" href={project.source} target="_blank" rel="noreferrer">Source code</a>
     
    </div>
    <img className="project-image" src={project.image} alt="projects" /> 

    </div>
  ))

  return (
    <section id="projects">
      <h1 className="section-title">projects</h1>
      {projects}
    </section>

  )
}

export default projects;