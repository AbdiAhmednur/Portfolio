

function landingPage() {
  return (
    <>
      <section id="landing" className="landing">
        <h1 className="landing-title">
          Hi, my name is <strong className="name">Abdirahman Ahmednur</strong>. I am a web developer.
        </h1>
      </section>
      <div className="lb">
        <button> <a href="#about">About me</a></button>
        <button> <a href="#projects">Projects</a></button>
        <button> <a  href="#contact">Contact me</a></button>
        <button><a href="../CV-Web-Development  .pdf">My CV</a></button>
        <button><a href="https://github.com/AbdiAhmednur">Github</a></button>
      </div>
    </>
  );
}

export default landingPage;
